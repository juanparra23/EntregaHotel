/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hotel2;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

/**
 *
 * @author 32344
 */
public class Room {
   
    private final double price;
    private final int id;
    private final int capacity;
    private boolean available;
    private User user;
    private Date dateStart;
    private Date dateFinish;


    public Room(double price, int id, int capacity) {
        this.price = price;
        this.id = id;
        this.capacity = capacity;
        this.available = true;
        this.dateStart = new Date();
    }

    
    public double getPrice() {
        return price;
    }

    public int getId() {
        return id;
    }

    public int getCapacity() {
        return capacity;
    }

    public boolean isAvailable() {
        return available;
    }

    public User getUser() {
        return user;
    }

    public Date getDateStart() {
        return dateStart;
    }

    public Date getDateFinish() {
        return dateFinish;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Date setDateFinish(int days) {
       if (days==0){ 
           return dateStart;
       }
      Calendar calendar = Calendar.getInstance();
      calendar.setTime(dateStart); 
      calendar.add(Calendar.DAY_OF_YEAR, days);  
       
        this.dateFinish = calendar.getTime();
        return calendar.getTime();
    }

    @Override
    public String toString() {
        return "Habitacion:{" + "precio = " + price + ", id = " + id + ", capacidad=" + capacity + ", disponible =" + available + ", fecha de ingreso = " + dateStart + ", fecha de salida = " + dateFinish + '}';
    }

   
    
   
    
    
    
    
    
     public void allocateRoom(User user, Room room, ArrayList<Room> available, ArrayList<Room> noDisponibles) {
        if (room.isAvailable()) {
            room.setUser(user);
            room.setAvailable(false);
            available.remove(room);
            noDisponibles.add(room);
            
            user.setStay(room.getPrice());
            System.out.println(this.toString());
            System.out.println("Habitacion asignada con exito a " + user.getName()+", id de habitacion: " + room.getId()+ ", el costo de la estadia va a ser: " + "$" + user.getStay() );
        } else {
            System.out.println("Lo siento, la habitacion no esta disponible.");
        }
    }
}

