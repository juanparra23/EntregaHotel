/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hotel2;

/**
 *
 * @author 32344
 */
public class User {
    
    private final String name;
    private final int id;
    private final String role;
    private double stay;
    private final int time;
    private int phone;

    public User(String name, int id, String role, int time, int phone) {
        this.name = name;
        this.id = id;
        this.role = role;
        this.time = time;
        this.phone = phone;
    }

    
    public String getName() {
        return name;
    }

    public int getId() {
        return id;
    }

    public String getRole() {
        return role;
    }
    public double getStay(){
        return stay;
    }
    public int getPhone(){
        return phone;
    }
    public void setPhone(int phone){
        this.phone = phone;
    }
    public void setStay(double price){
        this.stay = price * time;
        
    }
   
}

