/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hotel2;

/**
 *
 * @author 32344
 */
public class Recepcionist extends User {
    
    public Recepcionist(String name , int id, String role, int time, int phone) {
        super( name, id, role, time, phone);
    }
    
    
    public User makeUser(String nameUser,int idUser,String roleUser,int timeUser, int phoneUser){
        User newUser = new User(nameUser,idUser,roleUser,timeUser,phoneUser );
        return newUser;
    }
    
}


