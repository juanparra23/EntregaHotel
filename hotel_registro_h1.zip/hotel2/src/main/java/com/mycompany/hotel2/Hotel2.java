/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.hotel2;

import com.mycompany.hotel2.Room;
import com.mycompany.hotel2.User;
import com.mycompany.hotel2.Recepcionist;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author 32344
 */
public class Hotel2 {

    public static void main(String[] args) {

        
        Room[] roomsNormals = new Room[100];
        Room[] roomsBigs = new Room[100];
        Room[] roomsPremium = new Room[100];

        
        ArrayList<Room> available = new ArrayList<>();
        ArrayList<Room> unAvailable = new ArrayList<>();

        
        for (int i = 0; i < 100; i++) {
            roomsNormals[i] = new Room(140000, i + 1, 2);
            roomsBigs[i] = new Room(250000, i + 101, 4);
            roomsPremium[i] = new Room(500000, i + 201, 6);

            
            available.add(roomsNormals[i]);
            available.add(roomsBigs[i]);
            available.add(roomsPremium[i]);
        }
        
        
        Recepcionist recepcionist1 = new Recepcionist("Elio",1,"recepcionista",6,234453253);

        Scanner scanner = new Scanner(System.in);
        ArrayList<User> users = new ArrayList<>();
        Room choise = null;

        do {
            System.out.println("Ingrese el nombre del usuario:");
            String nameUser = scanner.nextLine();
            System.out.println("Ingrese el ID del usuario:");
            int idUser = scanner.nextInt();
            scanner.nextLine(); 
            System.out.println("Ingrese la ocupacion del usuario:");
            String roleUser = scanner.nextLine();
            System.out.println("Ingrese el numero de dias a quedarse:");
            int timeUser = scanner.nextInt();
            System.out.println("Ingrese su numero de telefono");
            int phoneUser = scanner.nextInt();
            System.out.println("elija escribiendo el numero si quiere: 1.una habitacion normal, 2.una habitacion grande o 3.una habitacion premium");
            int choiseRoom = scanner.nextInt();
            
            switch (choiseRoom) {
                case 1:
                    if (roomsNormals[0].isAvailable() == true) {
                        choise = roomsNormals[0];
                        choise.setDateFinish(timeUser);
                    } else {
                        for (int i = 1; i <= roomsNormals.length; i++) {
                            if (roomsNormals[i].isAvailable() == true) {
                                choise = roomsNormals[i];
                                choise.setDateFinish(timeUser);
                                break;
                            }
                        }
                    }
                    ;
                    break;
                case 2:
                    if (roomsBigs[0].isAvailable() == true) {
                        choise = roomsBigs[0];
                        choise.setDateFinish(timeUser);
                    } else {
                        for (int i = 1; i <= roomsBigs.length; i++) {
                            if (roomsBigs[i].isAvailable() == true) {
                                choise = roomsBigs[i];
                                choise.setDateFinish(timeUser);
                                break;
                            }
                        }
                    }
                    ;
                    break;
                case 3:
                    System.out.println("caso 3");
                    if (roomsPremium[0].isAvailable() == true) {
                        choise = roomsPremium[0];
                        choise.setDateFinish(timeUser);
                    } else {
                        for (int i = 1; i <= roomsPremium.length; i++) {
                            if (roomsPremium[i].isAvailable() == true) {
                                choise = roomsPremium[i];
                                choise.setDateFinish(timeUser);
                                break;
                            }
                        }
                    }
                    ;
                    break;
            }
            
            
            User newUser = recepcionist1.makeUser(nameUser, idUser, roleUser, timeUser, phoneUser);
            users.add(newUser);
            
            

            choise.allocateRoom(newUser, choise, available, unAvailable);
            
           

            System.out.println("¿Desea reservar otra habitacion? (Si o No)");
            String answer = scanner.next();
            if (!answer.equalsIgnoreCase("Si")) {
                break;
            }
            scanner.nextLine(); 
        } while (true);
    }

  
}
